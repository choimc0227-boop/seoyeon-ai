# 두근두근 AI · 서연 (모바일 웹앱)

## 폰에서 시작하기
1. ZIP 압축을 풀어 파일 5개를 준비합니다.
2. GitHub 웹사이트에서 새 공개 저장소를 만들고 파일을 업로드합니다. (GitHub 계정 필요)
3. Settings → Pages → Deploy from a branch → main / root → Save를 선택합니다.
4. 몇 분 뒤 표시되는 `https://사용자명.github.io/저장소명/` 주소를 Chrome으로 엽니다.
5. Chrome 메뉴 → 홈 화면에 추가 / 앱 설치를 선택합니다.

GitHub Pages에 공개 배포하면 소스와 정적 리소스는 공개됩니다. 채팅 기록은 현재 브라우저의 localStorage에 저장됩니다. 브라우저 데이터 삭제 시 사라질 수 있습니다.

## AI 모드
기본 채팅은 미리 정해진 체험용 응답입니다. 실제 생성형 AI를 사용하려면 HTTPS 서버를 별도로 배포해야 합니다. 설정 화면에 그 서버의 `/chat` URL을 입력하세요. 서버는 `POST` JSON `{ "messages": [{"role":"user","content":"안녕"}], "affection": 10 }`을 받고 `{ "reply": "안녕!" }`을 반환해야 합니다. 서버에서 CORS를 웹앱 출처에 허용해야 합니다. AI 제공자 API 키는 반드시 서버 환경변수에만 보관하세요. 대화 내용이 서버로 전송될 수 있으므로 개인정보 입력에 주의하세요.

## 이미지
현재 포함된 초상화는 임시 SVG 일러스트입니다. 실사형으로 바꾸려면 권리 확보된 성인 캐릭터 사진을 `portrait.jpg`로 추가하고 index.html의 `portrait.svg` 참조를 `portrait.jpg`로 변경하세요.
